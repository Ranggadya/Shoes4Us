import { ProductRepository } from '../repositories/ProductRepostory';
import { ProductCreateInput, ProductUpdateInput, ProductFilterInput } from '@/types/ProductType';
import { NotFoundError } from '@/exceptions/NotFoundError';
import { ForbiddenError } from '@/exceptions/ForbidenError';
import { Product } from '@prisma/client';

interface PaginationMeta {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

interface PaginatedProducts {
  products: Product[];
  meta: PaginationMeta;
}

export class ProductService {
  private productRepository: ProductRepository;

  constructor() {
    this.productRepository = new ProductRepository();
  }

  async getAllProducts(
    filter?: ProductFilterInput & { page?: number; limit?: number }
  ): Promise<PaginatedProducts> {
    const page = filter?.page ?? 1;
    const limit = filter?.limit ?? 10;

    const result = await this.productRepository.findAll({ ...filter, page, limit });

    return {
      products: result.products,
      meta: {
        page: result.page,
        limit: result.limit,
        total: result.total,
        totalPages: Math.ceil(result.total / result.limit),
      },
    };
  }

  async getProductById(id: string): Promise<Product> {
    const product = await this.productRepository.findById(id);
    if (!product) {
      throw new NotFoundError('Product');
    }
    return product;
  }

  async getProductBySlug(slug: string): Promise<Product> {
    const product = await this.productRepository.findBySlug(slug);

    if (!product) {
      throw new NotFoundError('Product');
    }
    return product;
  }

  async createProduct(data: ProductCreateInput): Promise<Product> {
    const existingProduct = await this.productRepository.findBySlug(data.slug);
    if (existingProduct) {
      throw new ForbiddenError('Product with this slug already exists');
    }

    return this.productRepository.create(data);
  }

  async updateProduct(id: string, data: ProductUpdateInput): Promise<Product> {
    const existingProduct = await this.productRepository.findById(id);
    if (!existingProduct) throw new NotFoundError('Product');

    if (data.slug && data.slug !== existingProduct.slug) {
      const slugExists = await this.productRepository.findBySlug(data.slug);
      if (slugExists) throw new ForbiddenError('Product with this slug already exists');
    }

    return this.productRepository.update(id, data);
  }

  async deleteProduct(id: string): Promise<{ message: string }> {
    const product = await this.productRepository.findById(id);
    if (!product) throw new NotFoundError('Product');

    await this.productRepository.delete(id);
    return { message: 'Product deleted successfully' };
  }
}